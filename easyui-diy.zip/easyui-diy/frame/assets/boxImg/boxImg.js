var jq = window.parent.$;
var zoom_n = 1;
$(document).keyup(function(event){
	if(jq(".mask-layer").length && event.keyCode == 27){
		jq(".mask-layer").remove();
	}
});
function loadMask(url){
	zoom_n = 1;
    jq("body").append("<div class=\"mask-layer\">" +
        "   <div class=\"mask-layer-black\"></div>" +
        "   <div class=\"mask-layer-container\">" +
        "       <div class=\"mask-layer-container-operate\">" +
        "           <a class=\"mask-close btn-default-styles icon-boximg-close\"></a>" +
        "       </div>" +
        "       <div class=\"mask-layer-imgbox auto-img-center\"></div>" +
        "   </div>" +
        "</div>"
    );
    showImg(url);
}

function showImg(url) {
    jq(".mask-layer-imgbox").append("<p><img src=\"\" alt=\"\"></p>");
    jq(".mask-layer-imgbox img").prop("src", url); //���������Img��ֵ

    //ͼƬ������ʾ
    var box_width = jq(".auto-img-center").width(); //ͼƬ���ӿ���
    var box_height = jq(".auto-img-center").height();//ͼƬ�߶ȸ߶�
    var initial_width = jq(".auto-img-center img").width();//��ʼͼƬ����
    var initial_height = jq(".auto-img-center img").height();//��ʼͼƬ�߶�
    if (initial_width > initial_height) {
        jq(".auto-img-center img").css("width", initial_width);
        var last_imgHeight = jq(".auto-img-center img").height();
        jq(".auto-img-center p").css("top", -(last_imgHeight - box_height) / 2);
        jq(".auto-img-center p").css("left", -(jq(".auto-img-center img").width() - box_width) / 2);
    } else {
        jq(".auto-img-center img").css("height", initial_height);
        var last_imgWidth = jq(".auto-img-center img").width();
        jq(".auto-img-center p").css("top", -(jq(".auto-img-center img").height() - box_height) / 2);
        jq(".auto-img-center p").css("left", -(last_imgWidth - box_width) / 2);
    }
    
    jq(".mask-layer-imgbox").on("mousewheel", function(event) {
    	event = event || window.event;
    	event.originalEvent.wheelDelta/120 > 0 ? zoomUp() : zoomDown();
    });
    
    //ͼƬ��ק
    var $div_img = jq(".mask-layer-imgbox p");
    //����������ס�¼�
    $div_img.bind("mousedown", function (event) {
        event.preventDefault && event.preventDefault(); //ȥ��ͼƬ�϶���Ӧ
        event.stopPropagation();
        //��ȡ��Ҫ�϶��ڵ������
        var offset_x = $(this)[0].offsetLeft;//x����
        var offset_y = $(this)[0].offsetTop;//y����
        //��ȡ��ǰ��������
        var mouse_x = event.pageX;
        var mouse_y = event.pageY;
        //���϶��¼�
        //�����϶�ʱ�����������Ƴ�Ԫ�أ�����Ӧ��ʹ��ȫ�֣�document��Ԫ��
        jq(".mask-layer-imgbox").bind("mousemove", function (ev) {
            // ��������ƶ��˵�λ��
            var _x = ev.pageX - mouse_x;
            var _y = ev.pageY - mouse_y;
            //�����ƶ����Ԫ������
            var now_x = (offset_x + _x ) + "px";
            var now_y = (offset_y + _y ) + "px";
            //�ı�Ŀ��Ԫ�ص�λ��
            $div_img.css({
                top: now_y,
                left: now_x
            });
        });
    });
    //���������ɿ����Ӵ��¼���
    jq(".mask-layer-imgbox").bind("mouseup", function () {
    	jq(this).unbind("mousemove");
    });
    //
    jq(".mask-layer-imgbox").bind("mousedown",function(){
    	maskClose();
    })
    //�ر�
    jq(".mask-close").click(function () {
    	maskClose();
    });
}

function maskClose(){
	jq(".mask-layer").remove();
}
//���� �Ŵ�
function zoomUp(){
    zoom_n += 0.1;
    jq(".mask-layer-imgbox img").css({
        "transform": "scale(" + zoom_n + ")",
        "-moz-transform": "scale(" + zoom_n + ")",
        "-ms-transform": "scale(" + zoom_n + ")",
        "-o-transform": "scale(" + zoom_n + ")",
        "-webkit-transform": "scale(" + zoom_n + ")"
    });
}
function zoomDown(){
    zoom_n -= 0.1;
    zoom_n = zoom_n <= 0.1 ? 0.1 : zoom_n;
    jq(".mask-layer-imgbox img").css({
        "transform": "scale(" + zoom_n + ")",
        "-moz-transform": "scale(" + zoom_n + ")",
        "-ms-transform": "scale(" + zoom_n + ")",
        "-o-transform": "scale(" + zoom_n + ")",
        "-webkit-transform": "scale(" + zoom_n + ")"
    });
}