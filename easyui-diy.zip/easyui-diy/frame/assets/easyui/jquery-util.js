;(function($,win,doc,top){
	$.extend({
		log :function(t,f){
			win.console && win.console.log(f ? String(t) : t);
		},
		error :function(s){
			throw new Error( String(s) );
		},
		topProName:function(undefined){
			return top.window.location.pathname.split("/")[1];
		},
		proName:function(undefined){
			return window.location.pathname.split("/")[1];
		},
		proPath:function(undefined){
			return this.hostPath() + this.proName();
		},
		hostPath:function(undefined){
			return "http://"+window.location.host+"/";
		},
		loadErrorPic:function(dom ,delay){
			var that  = this ,s =  this.proPath()+"/frame/assets/images/nopic.png";
			if(dom){
				setTimeout(function(){
				  $(dom).attr("src",s);
				},delay || that.rndNum(3));
			}
 		}, 
 		rndNum:function (n,max){
 			var rnd="";
 			for(var i=0;i<n;i++){
 				rnd += Math.floor(Math.random()*10);
 			}
 			if(!!max){
 				if(rnd > max) rnd = this.rndNum();
 			}
 			return rnd;
 		},
		uniqueId : function(){
			var S4 = function () {
		        return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
		    }
			return (S4() + S4() + "-" + S4() + "-" + S4() + "-" + S4() + "-" + S4() + S4() + S4());
		},
		formatDate:function(value,format){
			format 	= format || 'yyyy-MM-dd';
			value 	= value  || new Date(); 
			try{
				return value.format(format);
			}catch(e){
				return null;
			}
		},
		preloadImages :function(){
			  for (var i = 0; i < arguments.length; i++) {
			   	 $("<img/>").attr("src", arguments[i]);
			  }
			  return $;
		},
		getUrlParam:function(name){
			  	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");    
			  	var search = win.location.search.substr(1);
			  	var href = win.location.href;
			  	if(href.indexOf("?")>=0){
			  		search = href.substr(href.indexOf("?")+1);
			  	}
			  	var r = search.match(reg);    
			  	if (r != null) return decodeURI(r[2]); return null;    
		},
		ck : function(name, value, options) {
		    if (typeof value != 'undefined') {
		        options = options || {};
		        if (value === null) {
		            value = '';
		            options.expires = -1;
		        }
		        var expires = '';
		        if (options.expires && (typeof options.expires == 'number' || options.expires.toUTCString)) {
		            var date;
		            if (typeof options.expires == 'number') {
		                date = new Date();
		                date.setTime(date.getTime() + (options.expires * 24 * 60 * 60 * 1000));
		            } else {
		                date = options.expires;
		            }
		            expires = '; expires=' + date.toUTCString(); 
		        }
		        var path = options.path ? '; path=' + options.path : '';
		        var domain = options.domain ? '; domain=' + options.domain : '';
		        var secure = options.secure ? '; secure' : '';
		        doc.cookie = [name, '=', encodeURIComponent(value), expires, path, domain, secure].join('');
		    } else {
		        var cookieValue = null;
		        if (doc.cookie && doc.cookie != '') {
		            var cookies = doc.cookie.split(';');
		            for (var i = 0; i < cookies.length; i++) {
		                var cookie = jQuery.trim(cookies[i]);
		                if (cookie.substring(0, name.length + 1) == (name + '=')) {
		                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
		                    break;
		                }
		            }
		        }
		        return cookieValue;
		    }
		},
		addPageRetTip :function( str){
			str = str || "�����ϼ�";
			var docTitle = $("body").children(".layout-panel-north").first().find("div.panel-title:eq(0)");
			setTimeout(function(){
				docTitle && 
				docTitle[0].nodeName === 'DIV' && docTitle.find("a.title-ret").length == 0 && 
				docTitle.append('<a class="title-ret"><span class="title-retn-icon icon-title-rtn"></span><span>'+ str +'</span></a>');
				docTitle.find("a").bind('click',function(){win.history.go(-1)});
			},500);	
			return $;
		},
		objToStr :function(obj){
			if(!obj ||!($.isJsonObj(obj))) return null;
			var  str = "{";
			for(var m in obj ){
				str= str + m+ ':"' + String(obj[m]) +'",' ;
			}
			return str = str.substring(0,str.length-1) +"}";
		},
		isJsonObj : function(obj){ 
			return typeof(obj) == "object" && Object.prototype.toString.call(obj).toLowerCase() == "[object object]" && !obj.length;;
		},
		isIE : function(){
			return  /msie/.test(navigator.userAgent.toLowerCase());
		},
		isFireFox : function(){
			return /firefox/.test(navigator.userAgent.toLowerCase());
		},
		isChrome:function(){
			return /webkit/.test(navigator.userAgent.toLowerCase());
		},
		isModernBrowser:function(){
			//retun borwsers include(ie lge 8 chrome firefox)
			return 'undefined' !== typeof ('1'[0]);
		},
		isIE678:function(){
			return win == doc && doc !== win ;
		},
		checkIdNumber:function(idNumber){
			return (/(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/).test(idNumber);  
		      
		},
		checkMobile:function(mobile){
			return (/^1[3-9][0-9]\d{8}$/).test(mobile);
		},
		checkTelephone:function(telephone){
		     var re = /^0\d{2,3}-?\d{7,8}$/;
		    if(re.test(telephone)){
		        return true;
		    }else{
		        return false;
		    }
		},
		checkChinese:function(val){
			var reg = new RegExp("[\\u4E00-\\u9FFF]+","g");
			return reg.test(val);     
		},
		checkEmail:function(Email){
			var rs = 1;
		    if(Email == '') {
		        rs	= 2; 
		    } else {
		    	var re	= /^([\.a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+((\.[a-zA-Z0-9_-]{1,15}){1,5})$/;
		    	if(!re.test(Email)){
		            rs	= 3;
		        }
		    }
		    return rs;
		},
		cutString:function(Str, Length){
		    Str = $.trim(Str);
		    var Count = 0, RetStr = '',
		        StrArr = Str.split("");
		    for(var i=0; i<Str.length; i++){
		        iCode = Str.charCodeAt(i);
		        if((iCode >= 0 && iCode <= 255)||(iCode >= 0xff61 && iCode <= 0xff9f)){
		            Count += 1;
		        }else{
		            Count += 2;
		        }
		        if(Count <= Length){
		            RetStr += StrArr[i];
		        }	
		    }
		    return RetStr;
		},
		obj2ary:function(d,sort){
			var m = [],tmp =[];
			for(var x in d){
				if(x === "") tmp = [x,d[x]];
				else m[m.length] = [parseInt(x)||x,d[x]];
			} 
			tmp.length  &&  m.unshift(tmp);
			return (!!sort ? m.sort() : m ) || []; 
		},
		runDelay:function(f,delay){
			$.type(f) ==='function' && setTimeout(f , parseInt(delay) || 0 ,10 );
		 },
		getTodayStart: function (o,time) {
			var date = new Date();
			if(time){
				date = new Date(date.getTime() + time * 24 * 3600 * 1000);
			}
			return date.format("yyyy-MM-dd") + " " + (o || "00:00:00");
		},
		getTodayEnd: function (o,time) {
			var date = new Date();
			if(time){
				date = new Date(date.getTime() + time * 24 * 3600 * 1000);
			}
			return  date.format("yyyy-MM-dd") + " " + (o || "23:59:59");
		},
		getTopWindowById : function(wid){
			if(wid){
				var frame 	= top.$("#"+wid).children("iframe")[0];
				return (frame.contentWindow||frame.window);
			}
			return null;
		},
		getFormValues : function(formId ,winId){
			var win = winId ? this.getTopWindowById(winId): window ,form = win.$("#"+formId);
			var jq =  win.$,idxof = ''.indexOf ,s=''.substring ,v='getValue',t='getText',u='options',n="checked",n0='onText',n1='offText',m='tree';
			var type =['easyui-textbox','easyui-combobox',"easyui-datebox","easyui-datetimespinner","easyui-timespinner","easyui-searchbox",'easyui-datetimebox','easyui-switchbutton','easyui-combotree','easyui-numberbox','easyui-timespinner'];
			return !!form ?  
					(function(){
						var rows = form.find("input,select"),obj = {};
						if(rows.length){
							$.each(rows,function(i,o){  
								o = jq(o);
								var outget = o.attr('autoGet') || o.attr('autoget');
								if(String(outget) !== 'false'){
									var id = o.attr('id') , cls = o.attr('class');
									if(id && cls){
										if(idxof.call(cls,type[0])==0) obj[id] = (o[s.call(type[0],7)])(v);
										else if(idxof.call(cls,type[1])==0){
											obj[id] = (o[s.call(type[1],7)])(v);
											obj[id+"_text"] = (o[s.call(type[1],7)])(t);
										}
										else if(idxof.call(cls,type[2])==0) obj[id] = (o[s.call(type[2],7)])(v); 
										else if(idxof.call(cls,type[3])==0) obj[id] = (o[s.call(type[3],7)])(v);
										else if(idxof.call(cls,type[4])==0) obj[id] = (o[s.call(type[4],7)])(v);
										else if(idxof.call(cls,type[5])==0) obj[id] = (o[s.call(type[5],7)])(v);
										else if(idxof.call(cls,type[6])==0) obj[id] = (o[s.call(type[6],7)])(v);
										else if(idxof.call(cls,type[7])==0) {
											obj[id] = (o[s.call(type[7],7)])(u)[n];
											obj[id+"_text"]  = (o[s.call(type[7],7)])(u)[obj[id] ?n0 :n1];
										}
										else if(idxof.call(cls,type[8])==0){
											obj[id] = (o[s.call(type[8],7)])(v);
											obj[id+"_text"] = (o[s.call(type[8],7)])(t);
										}
										else if(idxof.call(cls,type[9])==0) obj[id] = (o[s.call(type[9],7)])(v);
										else if(idxof.call(cls,type[10])==0) obj[id] = (o[s.call(type[10],7)])(v);
									}
								}
							});
							return obj ;
						}
						return null;
					})() 
			  : null;
		},
		gridProgressBar:function( text ,width){
			return "<div class=\"progress\"><div class=\"progress-value\" style=\"width: "+(width||0)+"px;\"><div class=\"progress-text\">"+(text||"")+"</div></div></div>";
		},
		//ͼƬ��ַ���Ӵ���ǰ׺
		getPicProxyUrl:function(url,picProxy) {
			var isPicProxy = top.MainPage.isPicProxy;
			var proName = top.window.location.pathname.split("/")[1];
			var sysUrl = "http://"+window.location.host+"/"+proName;

			//������ͼƬ����
			if(!isPicProxy || isPicProxy ==='0') return url;
			//����ͼƬ����
			if(isPicProxy == "1"){
				//�������ݿ����
				var picProxyUrl = url;
				var picProxyMap = top.MainPage.picProxyMap;
				var picProxyGetUrl = ""; 
				if(!picProxy){
					picProxyGetUrl = sysUrl+"/sourceProxy?fileType=picUrlProxy&picUrl=";
				}else{
//					picProxyIp : "192.168.8.16"
//					picProxyUrl : "http://192.168.8.16:8080/pac/sourceProxy?fileType=picUrlProxy&picUrl="
					picProxyGetUrl = picProxyMap[picProxy].picProxyUrl;
				}
				return  picProxyUrl =  !!picProxyGetUrl ? (picProxyGetUrl+url) : url ;
			}
		},
		setAnchorHtml:function(hrefArr){
			var anchorHtml = [],data;
			if(hrefArr && hrefArr.length > 0){
				anchorHtml.push('<div id="pageAnchorList" style="position:fixed;border:1px solid #ddd;width:100px;right:20px;top:20%;">');
				anchorHtml.push('<a class="anchor" href="#">�ص�����</a>');
				for(var i=0;i<hrefArr.length;i++){
					data = hrefArr[i];
					anchorHtml.push('<a class="anchor" href="#'+ data.id +'">'+ data.name +'</a>');
				}
			}
			anchorHtml.push('</div>');
			return anchorHtml.join('')
		}
	});
	
})(jQuery,window,document ,top);