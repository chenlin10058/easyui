var treeLoadFilter = function (data, parent) {
    var opt = $(this).data().tree.options;
    var idFiled, textFiled, parentField ,len = data.length;
    if (opt.parentField) {
        idFiled = opt.idFiled || 'id';
        textFiled = opt.textFiled || 'text';
        parentField = opt.parentField ||'parentId';
        var i, l, treeData = [], tmpMap = [];
        for (i = 0, l = len; i < l; i++) {
            tmpMap[data[i][idFiled]] = data[i];
        }
        for (i = 0, l = len; i < l; i++) {
        	data[i].id= data[i][idFiled];
            if (tmpMap[data[i][parentField]] && data[i][idFiled] != data[i][parentField]){
                if (!tmpMap[data[i][parentField]]['children']){
                    tmpMap[data[i][parentField]]['children'] = [];
                }
                data[i]['text'] = data[i][textFiled];
                tmpMap[data[i][parentField]]['children'].push(data[i]);
            } else {
                data[i]['text'] = data[i][textFiled];
                treeData.push(data[i]);
            }
        }
        if(!opt.xzNode){
        	for (i = 0; data[i] ; i++){
            	if( data[i].children && data[i].children.length){
            		data[i].state = (!data[i].roleLevel || data[i].roleLevel > 0 )  ? 'closed' :'open';
            		data[i].iconCls = "icon-folder";
            	}else{
            		delete data[i].state;
            		data[i].iconCls = "icon-node";
            	}
            }
        }
        return treeData;
    }
    return data;
}; 
$.fn.tree.defaults.loadFilter = treeLoadFilter;

$.fn.treegrid.defaults.loadFilter = function (data, parentId) {
    var opt = $(this).data().treegrid.options;
    var idFiled, textFiled, parentField;
    if (opt.parentField) {
        idFiled = opt.idFiled || 'id';
        textFiled = opt.textFiled || 'text';
        parentField = opt.parentField;
        var i, l, treeData = [], tmpMap = [];
        for (i = 0, l = data.length; i < l; i++) {
            tmpMap[data[i][idFiled]] = data[i];
        }
        for (i = 0, l = data.length; i < l; i++) {
            if (tmpMap[data[i][parentField]] && data[i][idFiled] != data[i][parentField]) {
                if (!tmpMap[data[i][parentField]]['children'])
                    tmpMap[data[i][parentField]]['children'] = [];
                data[i]['text'] = data[i][textFiled];
                tmpMap[data[i][parentField]]['children'].push(data[i]);
            } else {
                data[i]['text'] = data[i][textFiled];
                treeData.push(data[i]);
            }
        }
        return treeData;
    }
    return data;
};

$.fn.combotree.defaults.loadFilter = $.fn.tree.defaults.loadFilter;

$.extend($.fn.tree.methods, {
	     getLevel:function(jq,target){
	         var l = $(target).parentsUntil("ul.tree","ul");
	         return l.length+1;
	     }
});