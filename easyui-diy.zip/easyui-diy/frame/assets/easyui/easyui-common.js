;(function($,top,window) {
	Date.prototype.format = function(format) {
		var o = {
			"M+" : this.getMonth() + 1,
			"d+" : this.getDate(),
			"h+" : this.getHours(),
			"m+" : this.getMinutes(),
			"s+" : this.getSeconds(),
			"q+" : Math.floor((this.getMonth() + 3) / 3),
			"S" : this.getMilliseconds()
		}
		if (/(y+)/.test(format)) {
			format = format.replace(RegExp.$1, (this.getFullYear() + "")
					.substr(4 - RegExp.$1.length));
		}
		for ( var k in o) {
			if (new RegExp("(" + k + ")").test(format)) {
				format = format.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k]
						: ("00" + o[k]).substr(("" + o[k]).length));
			}
		}
		return format;
	};
	
	Array.prototype.uniqueData = function(){
		 var res = [];
		 var json = {};
		 for(var i = 0; i < this.length; i++){
		  if(!json[this[i]]){
		   res.push(this[i]);
		   json[this[i]] = 1;
		  }
		 }
		 return res;
	};
	
	function createUUID() {
		function _p() {
		       return (((1+Math.random())*0x10000)|0).toString(16).substring(1);
		    }
		return (_p()+_p()+"-"+_p()+"-"+_p()+"-"+_p()+"-"+_p()+_p()+_p());
	}
 
	function destroy(target) {
		var options = $(target).dialog("options");
		$(target).dialog("close");
	}

	function getWindow(target) {
		if (typeof target == "string") {
			return document.getElementById(target);
		} else {
			return $(target).parents(".window-body");
		}
	}

	// ��ڷ���
	$.createWin = function(options) {
		if (!options.url) {
			$.messager.alert("��ʾ", "ȱ�ٱ�Ҫ����!(url or content)");
			return false;
		}
		
		var windowId = createUUID();
		
		options.id = windowId;
		
		if(!options.onClose){
			options.onClose = function(){};
		}
		
		var closeBtn = {
			text:$.fn.textbox.defaults.close,
			handler : function() {
				$("#" + windowId).dialog("close");
			}
		};
		
		options.url = options.url + ( options.url.indexOf("?")>=1 ?"&":"?" ) + "winId="+options.id;
		
		if(!options.buttons){
			options.buttons = [] ;
		}
		
		options.buttons.push(closeBtn);
		options = top.$.extend({}, $.createWin.defaults, options || {});
		var dialog = $('<div id="' + windowId + '"></div>');
		dialog.appendTo(top.$('body'));
		top.$(dialog).html('<iframe width="100%" height="100%" frameborder="0" src="'+ options.url + '" ></iframe>');
		dialog.dialog(options); 
		if (options.onComplete) {
			options.onComplete.call(this, windowId);
		}
		dialog.dialog('open');
		return windowId;
	};

	// �رղ�����ʵ��
	$.fn.destroy = function(win) {
		destroy(win||this);
	};

	window.GETWIN = getWindow;
	
	// Ĭ�ϲ���
	$.createWin.defaults = $.extend({}, $.fn.dialog.defaults, {
		url : '',
		data : '',
		target : 'body',
		isIframe : false,
		zIndex : 100000,
		height : 200,
		width : 400,
		collapsible : false,
		minimizable : false,
		maximizable : false,
		closed: true,
		closable: true,
		modal : true,
		onClose : function() {
			destroy(this);
		}	
	});
})(jQuery,top,window);
 
/**
 * jQuery ��form����Ԫ�ص�ֵ���л��ɶ���
 */
$.extend($.fn.form.methods, {
	serialize : function(jq) {
		var arrayValue = $(jq[0]).serializeArray();
		var json = {};
		$.each(arrayValue, function() {
			var item = this;
			var value = "";

			if (item["value"] != null) {
				value = item["value"].replace(/(^\s*)|(\s*$)/g, "");
			}

			if (value == '---��ѡ��---') {
				value = '';
			}

			if (json[item["name"]]) {
				json[item["name"]] = json[item["name"]] + "," + value;
			} else {
				json[item["name"]] = value;
			}
		});
		return json;
	},
	getValue : function(jq, name) {
		var jsonValue = $(jq[0]).form("serialize");
		return jsonValue[name];
	},
	setValue : function(jq, data) {
		return jq.each(function() {
			$(this).form("load", data);
		});
	}
});
/**
 * easyui ������ʾ��򵥷�װ
 */
(function($) {
	function alertDlg(title, msg, icon, fn) {
		top.jQuery.messager.alert(title, msg, icon, function() {
			if (fn) {
				fn();
			}
		});
	}
	$.dlg = {
		alertError : function(msg, fn) {
			alertDlg('����', msg, 'error', fn);
		},
		alertInfo : function(msg, fn) {
			$.showMsg(msg);
		},
		alertQuestion : function(msg, fn) {
			alertDlg('ѯ��', msg, 'question', fn);
		},
		alertWarning : function(msg, fn) {
			alertDlg('����', msg, 'warning', fn);
		},
		confirm : function(msg, fn, cancleFn) {
			top.jQuery.messager.confirm('ѯ��', msg, function(isOk) {
				if (fn && isOk) {
					fn();
				} else {
					if (cancleFn) {
						cancleFn();
					}
				}
			});
		}
	};
	
	$.showMsg = function(option){
		var t = $.type(option), fault = {'boolean':0,'string':1,'number':2,'object':3};
		if(!option || fault[t]<0 ) return;
		option = (fault[t]<3)?{msg:String(option)}:option;
		top.$.messager.show($.extend(true,{
	          height:40,
	          width:300,
	          showType:'fade',
	          showSpeed:200,
	          timeout:3000,
	          style:{top:document.body.scrollTop+document.documentElement.scrollTop+20}
			},option,{msg: "<span class='message-content'>"  + ( option.msg || "" ) + "</span>"}
		));

	}
})(jQuery);

(function($) {
	$.extend($.fn.layout.methods, {
		/**
		 * ����Ƿ���ںͿɼ�
		 * 
		 * @param {Object}
		 *            jq
		 * @param {Object}
		 *            params
		 */
		isVisible : function(jq, params) {
			var panels = $.data(jq[0], 'layout').panels;
			var pp = panels[params];
			if (!pp) {
				return false;
			}
			if (pp.length) {
				return pp.panel('panel').is(':visible');
			} else {
				return false;
			}
		},
		/**
		 * ���س�ĳ��region��center���⡣
		 * 
		 * @param {Object}
		 *            jq
		 * @param {Object}
		 *            params
		 */
		hidden : function(jq, params) {
			return jq.each(function() {
				var opts = $.data(this, 'layout').options;
				var panels = $.data(this, 'layout').panels;
				if (!opts.regionState) {
					opts.regionState = {};
				}
				var region = params;
				function hide(dom, region, doResize) {
					var first = region.substring(0, 1);
					var others = region.substring(1);
					var expand = 'expand' + first.toUpperCase() + others;
					if (panels[expand]) {
						if ($(dom).layout('isVisible', expand)) {
							opts.regionState[region] = 1;
							panels[expand].panel('close');
						} else if ($(dom).layout('isVisible', region)) {
							opts.regionState[region] = 0;
							panels[region].panel('close');
						}
					} else {
						panels[region].panel('close');
					}
					if (doResize) {
						$(dom).layout('resize');
					}
				}
				;
				if (region.toLowerCase() == 'all') {
					hide(this, 'east', false);
					hide(this, 'north', false);
					hide(this, 'west', false);
					hide(this, 'south', true);
				} else {
					hide(this, region, true);
				}
			});
		},
		/**
		 * ��ʾĳ��region��center���⡣
		 * 
		 * @param {Object}
		 *            jq
		 * @param {Object}
		 *            params
		 */
		show : function(jq, params) {
			return jq.each(function() {
				var opts = $.data(this, 'layout').options;
				var panels = $.data(this, 'layout').panels;
				var region = params;

				function show(dom, region, doResize) {
					var first = region.substring(0, 1);
					var others = region.substring(1);
					var expand = 'expand' + first.toUpperCase() + others;
					if (panels[expand]) {
						if (!$(dom).layout('isVisible', expand)) {
							if (!$(dom).layout('isVisible', region)) {
								if (opts.regionState[region] == 1) {
									panels[expand].panel('open');
								} else {
									panels[region].panel('open');
								}
							}
						}
					} else {
						panels[region].panel('open');
					}
					if (doResize) {
						$(dom).layout('resize');
					}
				}
				;
				if (region.toLowerCase() == 'all') {
					show(this, 'east', false);
					show(this, 'north', false);
					show(this, 'west', false);
					show(this, 'south', true);
				} else {
					show(this, region, true);
				}
			});
		}
	});
	
	$.extend($.fn.datagrid.methods, {
		 renderSwtcher:function(t,o,hidepager){
			 var tp = t.parent('.datagrid-view:eq(0)') ;
			 if(o && o.length && !tp.data('hasload')){
				 var i = 0,m = [],tb = tp.prev("div").append("<table cellspacing=0 cellpadding=0 style=\'display:inline-block;height:26px;float:right;\'><tbody><tr/></tbody></table>").children("table:eq(1)").find("tbody tr");
					 for(;o[i];){
						 var h = $('<a href="javascript:void(0)" class="l-btn l-btn-small l-btn-plain" ></a>'),_ = o[i];
						 var s0=$('<span class="l-btn-left l-btn-icon-left" style="line-height: 26px;"></span>'),s1 = $('<span class="l-btn-text"></span>'), s2 = $('<span class="l-btn-icon" style="margin-left: 2px;">&nbsp;</span>');
						 var wrapper = $("<td style='border: none;border-left: 1px solid #ccc; padding: 1px;'></td>");
						 _.id && h.attr('id',_.id);
						 _.group &&  h.attr('group',_ .group);
						 _.handler && h.bind('click',_.handler);
						 _.text && s1.text(_ .text);
						 _.iconCls && s2.addClass(_ .iconCls);
						 h.append(s0).children("span:eq(0)").append(s1).append(s2);
						 if(_.checked){
							 h.css("background","#E6E6E6");
							 tp.data('switcherCheck',i);
							i && tp.hide(100);
							i || tp.show(100) ;
						 }
						 wrapper.bind("click",function(){
							 var defaultHeight = tp.parent().height();
							 var defaultWidth  = tp.parent().width();
							 $(this).parent().find('td a').css("background","transparent");
							 $(this).find('a').css("background","#E6E6E6") ;
							 tp.data('switcherCheck',$(this).index());
							 var imgrender =  tp.parent().find("div.imgcontainer");
							 var chartrender =  tp.parent().find("div.chartContainer");
							 if($(this).index()){
								 tp.css('display','none');
								 imgrender 	 && imgrender.css({"display":"block",
										//"height":tp.parent().height()-70,
										"height":"calc(100% - 70px)",
										"width":"calc(100% - 1px)"
										});
								 chartrender && chartrender.css({"display":"block",
										//"height":tp.parent().height()-70,
										"height":"calc(100% - 70px)",
										"width":"calc(100% - 1px)"
										});
								 !!hidepager && tp.parent().find('div.pagination').hide(1);
							 }else{
								 imgrender 	 &&  imgrender.hide(1);
								 chartrender &&  chartrender.hide(1);
								 tp.css({
									 height:defaultHeight-70 ,
									 width: defaultWidth,
									 display :'block'
								 }).find('div.datagrid-header').css('height',"30px");
								 !!hidepager && tp.parent().find('div.pagination').css('display','block');
							 }
						 }).append(h);
						 tb.append(wrapper);
						 tp.data('hasload',true);
						 i++;
				 }
			 }
		 },
		 renderCheSwtcher:function(t,o){
			 this.renderSwtcher(t,o,false);
		 },
		 renderCheData:function(t,data){
			var tp = t.parent('.datagrid-view:eq(0)') , imgContainer ;
			var tr = tp.prev("div").append("<table cellspacing=0 cellpadding=0 style=\'display:inline-block;height:26px;float:right;\'><tbody><tr/></tbody></table>").children("table:eq(1)").find("tbody tr");
			var defaultHeight = tp.parent().height();
			var defaultWidth  = tp.parent().width();
			if(!tp.next("div.imgcontainer").html()){
				imgContainer = $("<div class='imgcontainer' style='width:"+( defaultWidth+1 )+"px;height:"+( defaultHeight-70 )+"px;display:none;'></div>").html('<div class="img-box"></div>');				
				tp.after(imgContainer);
			}else{
				imgContainer = tp.next("div.imgcontainer");
			}
			if(!data) return ;
			var i = 0,a = [],img,color,that = this;
			for(; (data.rows[i]) ; i ++){
				if (data.data[i].picUrl) {
					var picSrc = data.data[i].picUrl.split(";");
					var str = "";
					if (picSrc.length > 1) {
						for (var j = 0; j < picSrc.length; j++) {
							picSrc[j] = $.getPicProxyUrl(picSrc[j]);
							str += '<img src="' + picSrc[j] + '" style="display:none;" onload="javascript:$.getImgWidth(this)" onclick="showZoomInPic(this.src);" onerror="javascript:$.loadErrorPic(this);">';
						}
					} else {
						picSrc[0] = $.getPicProxyUrl(picSrc[0]);
						str = '<img src="' + picSrc[0] + '" onclick="showZoomInPic(this.src);" onerror="javascript:$.loadErrorPic(this);">';
					}
					a.push('<div class="view-item" picLen="' + picSrc.length + '">' + str + '<div>' + '<p>���ƺ���:&nbsp;<a style="color:blue;" onclick="opendialog(' + i + ')">' + (data.rows[i].plateNo || '') + '</a></p>' + '<p>��������:&nbsp;' + (data.rows[i].snapTime || '') + '</p>' + '<p>���·��:&nbsp;' + (data.rows[i].monitorLocationName || '') + '</p>' + '</div></div></div></div>');
				} else {
					a.push('<div class="view-item"><img src="" onclick="showZoomInPic(this.src);" onerror="javascript:$.loadErrorPic(this);"><div>' + '<p>���ƺ���:&nbsp;<a style="color:blue;" onclick="opendialog(' + i + ')">' + (data.rows[i].plateNo || '') + '</a></p>' + '<p>��������:&nbsp;' + (data.rows[i].snapTime || '') + '</p>' + '<p>���·��:&nbsp;' + (data.rows[i].monitorLocationName || '') + '</p>' + '</div></div></div></div>');
				}
			}
			imgContainer.find('.img-box').html(a.join(''));
			
			var idx = tp.data('switcherCheck') || 0 ,nextdom = tp.parent().find("div.imgcontainer");
			
			setTimeout(function(){
				if(idx){
					tp.css('display','none');
					nextdom.css('display','block');
				}else{
					nextdom.css('display','none');
					tp.css({
						 height:defaultHeight-70 ,
						 width: defaultWidth,
						 display :'block'
					}).find('div.datagrid-header').css('height',"30px");
				 }
			},0)
			return t ;
		 },
		 renderMonitorData:function(t,data,delay){
			var tp = t.parent('.datagrid-view:eq(0)') , imgContainer ;
			var tr = tp.prev("div").append("<table cellspacing=0 cellpadding=0 style=\'display:inline-block;height:26px;float:right;\'><tbody><tr/></tbody></table>").children("table:eq(1)").find("tbody tr");
			var defaultHeight = tp.parent().height();
			var defaultWidth  = tp.parent().width();
			if(!tp.next("div.imgcontainer").html()){
				imgContainer = $("<div class='imgcontainer' style='overflow-y:auto; width:99%;height:"+( defaultHeight-70 )+"px;'></div>");
				tp.after(imgContainer);
			}else{
				imgContainer = tp.next("div.imgcontainer");
			}
			if(!data) return ;
			var i = 0,a = [],img,color,that = this;
			for(;(data.data[i]);i++){
				data.data[i].oprStatusStr = data.data[i].oprStatus == 0 ? '����' : '�쳣';
				data.data[i].oprStatusColor = "style=\"color:"+( data.data[i].oprStatus == 0?'blue;':'red;') +'"';
				data.data[i].picUrl = $.getPicProxyUrl(data.data[i].picUrl) 	
				a.push('<div class="view-item">'+
						'<img  src="'+ (data.data[i].picUrl) +'" onclick="showZoomInPic(this.src);" onerror="javascript:$.loadErrorPic(this);"/><div>'+
						'<p>���������:&nbsp;'+ (data.data[i].channelNameName  || '��') +'</p>'+
						'<p>����ԭ��:&nbsp;'+ (data.data[i].reason || '') +'</p>'+
						'<p>����״̬:&nbsp;<span '+data.data[i].oprStatusColor+'>'+ (data.data[i].oprStatusStr || '') +'</span></p>'+
						'<p><a href="javascript:void(0);" tag='+ data.data[i].id +' class="ahref" onclick="oprStatus(this,0);" >�������</a> &nbsp;&nbsp;&nbsp; <a href="javascript:void(0);" tag='+ data.data[i].id +' class="ahref" onclick="oprStatus(this,1);" >����쳣</a></p>'+
						'</div></div>');
			 }
			imgContainer.html('<div class="img-box">'+a.join("")+'</div>');
		 },
		renderPersonData: function (t, data, delay) {
			console.log(data)
			var tp = t.parent(".datagrid-view:eq(0)"),
			imgContainer;
			var tr = tp.prev("div").append("<table cellspacing=0 cellpadding=0 style='display:inline-block;height:26px;float:right;'><tbody><tr/></tbody></table>").children("table:eq(1)").find("tbody tr");
			var defaultHeight = tp.parent().height();
			var defaultWidth = tp.parent().width();
			if (!tp.next("div.imgcontainer").html()) {
				imgContainer = $("<div class='imgcontainer' style='overflow-y:auto; width:99%;height:" + (defaultHeight - 70) + "px;'></div>");
				tp.after(imgContainer)
			} else {
				imgContainer = tp.next("div.imgcontainer")
			}
			if (!data || !data.data || !data.data.length) {
				imgContainer.html('<div class="img-box" style="font-size:16px;text-align:center;padding-top:80px;">û�в�ѯ�����������ļ�¼!</div>');
				return
			}
			var i = 0,
			a = [],
			img,
			color,
			that = this;
			for (; (data.data[i]); i++) {
				data.data[i].firstPhotoUrl = $.getPicProxyUrl(data.data[i].firstPhotoUrl) + "?" + (new Date).getDate();
				a.push('<div class="view-item person">' + '<img  src="' + (data.data[i].firstPhotoUrl) + '" onerror="javascript:$.loadErrorPic(this);"/><div>' + "<p style='margin-top:10px;'><span style='width: 120px;display: inline-block;text-overflow: ellipsis;overflow: hidden;' title='" + (data.data[i].name || "��") + "'>����:&nbsp;" + (data.data[i].name || "��") + "</span><span style='width:55px;float:right;display: inline-block;'>�Ա�:&nbsp;" + (data.data[i].sex || '') + "</span></p>" + "<p>����֤��:&nbsp;" + (data.data[i].idNumber || '') + "</p>"+"<p><span>����:&nbsp;" + (data.data[i].nation || "") + "</span><span tag='" + data.data[i].peopleId + "' onclick='delete_PersonFaceInfo_manual_ext(this)' class='ahref' style='display: inline-block;cursor:pointer;float:right;line-height:15px;'>ɾ��</span></p>" + "</div></div>")
			}
			imgContainer.html('<div class="img-box">' + a.join("") + "</div>")
		},
		renderPersonMachineData:function(t,data,delay){
					var tp = t.parent('.datagrid-view:eq(0)') , imgContainer ;
					var tr = tp.prev("div").append("<table cellspacing=0 cellpadding=0 style=\'display:inline-block;height:26px;float:right;\'><tbody><tr/></tbody></table>").children("table:eq(1)").find("tbody tr");
					var defaultHeight = tp.parent().height();
					var defaultWidth  = tp.parent().width();
					if(!tp.next("div.imgcontainer").html()){
						imgContainer = $("<div class='imgcontainer' style='overflow-y:auto; width:99%;height:"+( defaultHeight-70 )+"px;'></div>");
						tp.after(imgContainer);
					}else{
						imgContainer = tp.next("div.imgcontainer");
					}
					console.log(data)
					if(!data || !data.data || !data.data.length){
						imgContainer.html('<div class="img-box" style="font-size:16px;text-align:center;padding-top:80px;"> û�в�ѯ�����������ļ�¼!</div>');
						return;
					}
					var i = 0,a = [],img,color,that = this;
					for(;(data.data[i]);i++){
						data.data[i].firstPhotoUrl = $.getPicProxyUrl(data.data[i].firstPhotoUrl); 	
						a.push('<div class="view-item machine">'+
								'<img  src="'+ (data.data[i].firstPhotoUrl) +'" onerror="javascript:$.loadErrorPic(this);"/><div>'+
								'<p>&nbsp;'+ (data.data[i].channelName  || '��') +'</p>'+
								'<p>&nbsp;'+ (data.data[i].createTime || '') +'</p>'+
								'</div></div>');
					 }
					imgContainer.html('<div class="img-box">'+a.join("")+'</div>');
				 },
			 renderPersonCompareData:function(t,data,delay){
					var tp = t.parent('.datagrid-view:eq(0)') , imgContainer ;
					var tr = tp.prev("div").append("<table cellspacing=0 cellpadding=0 style=\'display:inline-block;height:26px;float:right;\'><tbody><tr/></tbody></table>").children("table:eq(1)").find("tbody tr");
					var defaultHeight = tp.parent().height();
					var defaultWidth  = tp.parent().width();
					if(!tp.next("div.imgcontainer").html()){
						imgContainer = $("<div class='imgcontainer' style='overflow-y:auto; width:99%;height:"+( defaultHeight )+"px;'></div>");
						tp.after(imgContainer);
					}else{
						imgContainer = tp.next("div.imgcontainer");
					}
					if(!data || !data.rows || !data.rows.length){
						imgContainer.html('<div class="img-box" style="font-size:16px;text-align:center;padding-top:80px;"> û�в�ѯ�����������ļ�¼!</div>');
						return;
					}
					var i = 0,a = [],img,color,that = this;
					for(;(data.rows[i]);i++){
						data.rows[i].personUrl = $.getPicProxyUrl(data.rows[i].personUrl)+"?"+(new Date()).getTime(); 	
						a.push('<div class="view-item">'+
								'<img  src="'+ (data.rows[i].personUrl) +'" onerror="javascript:$.loadErrorPic(this);"/><div>'+
								'<p>����:&nbsp;'+ (data.rows[i].name  || '��') +'<span style="float:right;color:red;">'+ (data.rows[i].nSimularity || '') +'</span></p>'+
								'<p>����֤��:&nbsp;'+ (data.rows[i].idNumber || '') +'</p>'+
								'</div></div>');
					 }
					imgContainer.html('<div class="img-box">'+a.join("")+'</div>');
				 },
		 renderHtmlStr:function(t,html){
		 	var tp = t.parent('.datagrid-view:eq(0)'),chartContainer ;
			var tr = tp.prev("div").append("<table cellspacing=0 cellpadding=0 style=\'display:inline-block;height:26px;float:right;\'><tbody><tr/></tbody></table>").children("table:eq(1)").find("tbody tr");
			var defaultHeight = tp.parent().height();
			var defaultWidth  = tp.parent().width();
			if(!tp.parent().find('div.chartContainer').html()){
				chartContainer = $("<div class='chartContainer' style='width:"+( defaultWidth-1 )+"px;height:"+( defaultHeight-32 )+"px;display:none;'></div>").html('<div class="chart-box"></div>');				
				tp.after(chartContainer);
			}else{
				chartContainer = tp.parent().find('div.chartContainer');
			}
			chartContainer.html(String(html));
		 },
		 renderChartSwitcher:function(t,o){
			 this.renderSwtcher(t,o,true);
		 }
	});
})(jQuery);
